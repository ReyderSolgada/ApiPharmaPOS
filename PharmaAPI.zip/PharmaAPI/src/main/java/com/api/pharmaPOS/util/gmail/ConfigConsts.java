package com.api.pharmaPOS.util.gmail;

public final class ConfigConsts {

	public static final String TO_EMAIL_ADDRESS = "sendToAddress@example.com";

	public static final String FROM_EMAIL_ADDRESS = "sendFromAddress@gmail.com";

	public static final String USER_NAME_EMAIL = "sendFromAddress@gmail.com";

	public static final String USER_PASSWORD = "********";

	public static final String FILE_PATH = "path/to/files";

	public static final String SMPT_HOST_ADDRESS = MailServers.GMAIL.getAddress();

	public static final String SMPT_HOST_NAME = MailServers.GMAIL.getName();
}
