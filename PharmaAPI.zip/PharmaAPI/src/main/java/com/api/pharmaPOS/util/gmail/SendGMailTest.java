package com.api.pharmaPOS.util.gmail;

public class SendGMailTest {

	public static void main(String[] args) {
		/*

		SendGmail gmail = new SendGmail();
		String mensaje = gmail.EnviarCorreoGmail("rsolgadapino@gmail.com", "PRUEBA CORREO GAMIL",
				"este es un mensaje de prueba para confirmar la contraseña del usuario");
		System.out.println(mensaje);
*/
	}

}
